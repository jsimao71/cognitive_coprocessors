# PATCH — Paper 2: Tokenizer-Aware CPU Trigger Ladder

## Motivation
The current Paper 2 trigger ladder should add a stronger lexical/tokenization comparison before escalating to neural routers or generative block selection.

The key question is:

> Can cheap CPU triggers discriminate computational families reliably when operating over model-token or linguistically tokenized representations?

This is especially relevant because the current five-engine LoRA failure may reflect interface/data/model issues rather than a need for a complex semantic router.

## Trigger classes
Keep the six-way task:
- NONE
- CALCULATOR
- DATE
- UNITS
- GRAPH
- DATALOG

## Tokenization conditions

1. Regex/word tokenizer
   Current simple lexical baseline.

2. Character n-grams
   Current robust surface-form baseline.

3. LLM-native tokenizer
   Use the exact tokenizer for each checkpoint.

4. Shared lightweight NLP tokenizer
   Use one common linguistic tokenizer across model families.

5. Optional second NLP tokenizer
   Only if cheap to install/run and substantially different.

## Matched feature methods
For each tokenization compare:

### F1 — unigram TF-IDF + linear classifier

### F2 — token n-gram TF-IDF + linear classifier

### F3 — BM25 example retrieval
Maintain a small indexed corpus per engine class.

For each prompt:
- tokenize;
- retrieve nearest training examples;
- aggregate by engine family;
- output class + confidence.

### F4 — class prototype lexical score
Build class-level weighted token vocabularies and score prompt overlap.

### F5 — deterministic parser/rule features
Retain existing arithmetic/date/unit/logic cues as an interpretable baseline.

## LLM-token specifics
Use token IDs/pieces as terms.

Test:
- unigrams;
- bigrams;
- BM25;
- IDF-weighted class prototypes.

Record whether symbolic/operator tokens make calculator/units/date especially easy.

Do not assume LLM tokenizer is semantically superior; subword fragmentation may hurt graph/Datalog semantics.

## Engine-family subgroup hypotheses

### Calculator
Expected to benefit from model tokens around:
- numerals;
- operators;
- punctuation.

### Date
Potential benefit from model tokens for date formats and temporal phrases.

### Units
Potential benefit from stable unit symbols/subwords.

### Graph/Datalog
Potentially better with linguistic tokens/word n-grams because semantic relations may be spread across BPE fragments.

This family-level comparison is important.

## Dataset requirements
Run tokenizer triggers on:
1. current Paper 2 frozen dataset;
2. richer next-round paraphrase dataset;
3. balanced TwIL reasoning/interface dataset where applicable.

Do not tune on held-out test.

## Metrics
Report:
- six-way classification accuracy;
- macro F1;
- per-engine precision/recall;
- false activation on NONE controls;
- confusion matrix;
- CPU latency;
- memory/index size;
- tokenization latency;
- robustness vs paraphrase/template shift.

## Compare to model classifiers
Tokenizer trigger results become stronger baselines for:
- base-model label-only classification;
- LoRA label-only classification;
- TwIL label-only classification;
- generative block interface.

The point is to determine whether the neural model is actually needed for routing.

## Hybrid trigger architecture
If cheap lexical/token triggers work well for some families but not others, allow hierarchical routing.

Example:

1. CPU parser/token trigger handles:
   - calculator
   - date
   - units

2. remaining ambiguous cases go to:
   - graph vs Datalog classifier
   - model/TwIL formalizer

This may be better than one universal six-way model router.

## BM25 exemplar router
Implement an explicit experiment:

prompt
-> tokenizer
-> BM25 over labeled trigger examples
-> top-k examples
-> weighted vote by engine class
-> threshold
-> engine or NONE

Measure:
- k = 1, 3, 5, 10;
- threshold;
- tokenization choice.

This keeps examples outside LLM context and moves routing to CPU.

## Production comparison
For each trigger method include:
- context tokens added: ideally zero;
- CPU cost;
- model calls avoided;
- failure mode;
- ease of updating with a new engine.

Adding a new coprocessor should ideally mean:
- add examples/rules/index entries;
- not retrain the whole LLM.

## Interpretation

### Outcome A — tokenizer/BM25 works very well
Prefer CPU routing for covered engine families.

### Outcome B — model tokenizer outperforms linguistic tokenizer
Supports model-aligned token-space triggers.

### Outcome C — linguistic tokenizer wins
Use linguistic segmentation for CPU semantics; do not force model BPE.

### Outcome D — lexical routing fails on graph/Datalog but works on arithmetic/date/units
Use hierarchical mixed routing.

### Outcome E — neural classification clearly dominates
Only then justify more complex learned routing.

## Relation to TwIL
Test TwIL only after the CPU tokenizer baselines are established.

A likely architecture may be:
- cheap CPU trigger for obvious compute families;
- TwIL/model formalizer for ambiguous logic;
- exact engine execution.

This should be compared directly.

## Immediate additions
1. tokenizer abstraction;
2. model-token adapters;
3. common NLP tokenizer;
4. BM25 exemplar router;
5. class-prototype scorer;
6. confusion/family-level analysis;
7. latency/memory accounting.

## Manuscript additions
Add subsection:
### Token-Space Triggers and CPU Routing

Make clear that the trigger ladder tests:
- chars;
- words;
- linguistic tokens;
- model tokens;
- BM25;
- semantic rules;
- neural classifiers.

## Deliverables
- tokenizer-aware trigger module;
- BM25 exemplar router;
- matched six-way trigger benchmark;
- per-family confusion tables;
- CPU latency/index-size results;
- hierarchical-routing ablation;
- updated recommendation on whether Paper 3 semantic routing remains justified.
