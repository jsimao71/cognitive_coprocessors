# PATCH — Paper 1.5: Tokenizer-Aware Trigger Experiments

## Motivation
The current natural-language robustness work includes lexical triviality audits using bag-of-words, word n-gram TF-IDF, and character n-gram TF-IDF. Add a stronger tokenizer-aware trigger comparison before attributing gains to higher-level semantic rules.

The new question is:

> Does representing trigger text in the same token space used by the LLM improve retrieval-required detection compared with lightweight linguistic tokenizers, word/character baselines, and current transparent semantic rules?

This is a trigger/representation experiment, not a new retrieval architecture.

## Tokenization conditions

Add matched trigger pipelines using:

1. Current word baseline
   - whitespace/regex word tokens
   - word n-grams

2. Character baseline
   - char n-grams

3. LLM-native tokenizer
   - exact tokenizer of each evaluated checkpoint
   - Qwen tokenizer for Qwen
   - SmolLM2 tokenizer for SmolLM2
   - Gemma tokenizer for Gemma

4. Shared lightweight NLP tokenizer
   Start with one simple dependency-light tokenizer, e.g.:
   - spaCy blank English tokenizer if available cleanly, or
   - NLTK/Treebank-style tokenizer, or
   - a small regex/punctuation-aware tokenizer

   Keep this tokenizer identical across model families.

5. Optional second lightweight NLP tokenizer
   Add only if setup is trivial and it provides materially different segmentation.

Do not make tokenizer installation complexity a focus of the paper.

## Feature/scoring conditions

For each tokenization, compare matched downstream methods:

### A. unigram TF-IDF + linear classifier

### B. token n-gram TF-IDF + linear classifier

### C. BM25-style class/example retrieval
Represent each trigger family as a small corpus of examples.
For a new prompt:
- tokenize;
- compute BM25 similarity;
- aggregate scores by class;
- trigger retrieval if best retrieval-required score exceeds threshold.

### D. exact/weighted token-pattern rules
Use only for interpretable diagnostic analysis.

Do not change the current transparent semantic policy while evaluating these baselines.

## LLM-token BM25
Treat tokenizer token IDs/pieces as lexical terms.

Compute:
- token document frequency;
- IDF;
- BM25 score;
- optional token bigrams.

Test both:
- raw token pieces;
- normalized token-piece strings where tokenizer exposes them.

Do not assume model-token BM25 is superior; BPE fragments may introduce noise.

## Cross-checkpoint representation question
There are two distinct comparisons:

### Model-aligned
Each checkpoint uses its own tokenizer.

### Shared tokenizer
All checkpoints use the same lightweight NLP tokenizer.

This allows asking:
> Is checkpoint stability improved by a common lexical representation, or by alignment with each model's own tokenization?

## Trigger benchmark
Run on:
1. original 80-example freeze;
2. natural-v5 untouched set;
3. any later paired hard-negative set if created.

Do not tune thresholds on test.

Use development-set threshold selection only.

## Metrics
Report:
- retrieval recall;
- false activation;
- precision/F1;
- UCR when connected to the same runtime enforcement;
- CPU latency;
- memory/index size;
- vocabulary size;
- robustness by semantic subclass.

Also report:
- tokenizer sequence length;
- average n-gram count;
- OOV/unknown behavior where applicable.

## Hard subgroup analysis
Especially compare on:
- current/source-specific;
- supplied-context;
- historical-copy false positives;
- quoted freshness language;
- private identifiers;
- computation-vs-retrieval controls;
- lexical distractors.

The key question is whether model-token lexical triggers reduce or worsen the historical-copy false positives.

## Interpretation
Possible outcomes:

### Outcome A — model tokenizer wins
Supports using the LLM tokenizer as a shared CPU trigger representation.

### Outcome B — lightweight NLP tokenizer wins
Suggests linguistic segmentation is more appropriate for epistemic policy than model BPE space.

### Outcome C — all lexical methods remain below semantic rules
Strengthens the claim that transparent semantic policy adds more than improved lexical engineering.

### Outcome D — token-BM25 nearly matches semantic rules
Then the production recommendation should prefer the cheaper lexical trigger unless semantic rules retain important robustness advantages.

## Scope
This does NOT reopen LoRA adaptation.

It is explicitly a CPU-side trigger comparison.

## Immediate additions
- tokenizer abstraction;
- model-token tokenizer adapters;
- one shared NLP tokenizer;
- BM25 scorer;
- matched TF-IDF classifier pipeline;
- per-subclass metrics;
- latency benchmark.

## Manuscript additions
Add a subsection:
### Tokenization and Lexical Trigger Strength

Clarify that the semantic-policy result is compared not only against chars/words but also against:
- same-model tokenization;
- linguistic tokenization;
- BM25/token n-gram triggers.

## Deliverables
- tokenizer comparison config;
- tokenized benchmark artifacts;
- BM25 implementation;
- matched trigger table;
- CPU latency table;
- updated lexical-triviality discussion;
- evidence-based recommendation for production trigger representation.
